function [beta, J] = logisticIRLSL2(X,y,lambda)
[n p] = size(X);
beta = zeros(p,1);
itr = 0;
J = 0;
while 1
  itr = itr + 1;
  prev_J = J;
  % compute J here
  %

  if abs(prev_J-J) < 0.01
    break;
  end

  % update beta here
  %
  %
  %
  %
  %

end
endfunction

function [y] = h(x)
y = 1.0 ./ (1.0 + exp(-x));
endfunction
