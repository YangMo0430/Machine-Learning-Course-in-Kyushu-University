% This function loads data and plot them.
load X;
load y;
pos = find(y==1);
neg = find(y==0);
figure;
plot(X(pos,1),X(pos,2),'r+');hold on;
legend('y=1');
plot(X(neg,1),X(neg,2),'go');hold off;legend('y=0');
