function []=plotLR(x,y,lambda,opt)
% A function to plot decision boundary
% This function requires logisticIRLSL2.m 
%
% Input
% x: data points (matrix)
% y: labels (vector)
% lambda: regularization parameter (scalar)
% opt: 1 or 2

if nargin==3
  opt = 2;
end

pos = find(y);
neg = find(y==0);
figure;
plot(x(pos,1),x(pos,2),'r+');hold on;
plot(x(neg,1),x(neg,2),'go');

X=map_feature(x(:,1),x(:,2));
[n p]=size(X)

if opt == 1
  [beta]=logisticIRLSL1(X,y,lambda);
elseif opt == 2
  [beta]=logisticIRLSL2(X,y,lambda);
end

u=linspace(-1,1.5,200);
v=linspace(-1,1.5,200);
z = zeros(length(u), length(v));

for i=1:length(u)
  for j=1:length(v)
    z(j,i)=map_feature(u(i),v(j))*beta;
  end
end
%z=z';

contour(u,v,z, [0,0], 'LineWidth', 2, 'LineColor', 'blue');
legend('y=1');
legend('y=0');
title(['lambda = ',num2str(lambda)]);
hold off;
% print -dgif lr.gif