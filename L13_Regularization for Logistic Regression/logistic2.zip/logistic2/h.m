function [y] = h(x)
y = 1.0 ./ (1.0 + exp(-x));
endfunction