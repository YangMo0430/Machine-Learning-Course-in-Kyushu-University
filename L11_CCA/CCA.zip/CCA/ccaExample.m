X =[7 7 13 7;4 3 14 7; 10 5 12 5; 16 7 11 3; 13 3 10 3]
Y =[14 10 8 2 6; 7 7 5 4 2; 8 6 5 7 4]'
[Wx Wy r U V]=cca(X,Y);
[n p]=size(X);
[n q]=size(Y);
plot(Wx(:,4),Wx(:,3),'ro');
text(Wx(1,4),Wx(1,3),'Price');
text(Wx(2,4),Wx(2,3),'Sugar');
text(Wx(3,4),Wx(3,3),'Alcohol');
text(Wx(4,4),Wx(4,3),'Acidity');
hold on
plot(U(:,4),U(:,3),'bo');
text(U(1,4),U(1,3),'Wine 1');
text(U(2,4),U(2,3),'Wine 2');
text(U(3,4),U(3,3),'Wine 3');
text(U(4,4),U(4,3),'Wine 4');
text(U(5,4),U(5,3),'Wine 5');
axis square;
xlabel('CC1');
ylabel('CC2');
title('X-space');
%print -dgif ccaWineX.gif
hold off

figure
plot(Wy(:,4),Wy(:,3),'go');
text(Wy(1,4),Wy(1,3),'Hedonic');
text(Wy(2,4),Wy(2,3),'Goes with meat');
text(Wy(3,4),Wy(3,3),'Goes with dessert');
hold on
plot(V(:,4),V(:,3),'bo');
text(V(1,4),V(1,3),'Wine 1');
text(V(2,4),V(2,3),'Wine 2');
text(V(3,4),V(3,3),'Wine 3');
text(V(4,4),V(4,3),'Wine 4');
text(V(5,4),V(5,3),'Wine 5');
axis square;
xlabel('CC1');
ylabel('CC2');
title('Y-space');
%print -dgif ccaWineY.gif
hold off
