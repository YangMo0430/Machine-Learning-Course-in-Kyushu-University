% demonstration of Latent Semantic Indexing
load LSI.mat;
[U S V]=svd(X);
figure;
% plot book space
plot(V(:,1),V(:,2),'.');
text(V(1,1),V(1,2),'B1');
text(V(2,1),V(2,2),'B2');
text(V(3,1),V(3,2),'B3');
text(V(4,1),V(4,2),'B4');
text(V(5,1),V(5,2),'B5');
text(V(6,1),V(6,2),'B6');
text(V(7,1),V(7,2),'B7');
text(V(8,1),V(8,2),'B8');
text(V(9,1),V(9,2),'B9');
text(V(10,1),V(10,2),'B10');
text(V(11,1),V(11,2),'B11');
text(V(12,1),V(12,2),'B12');
text(V(13,1),V(13,2),'B13');
text(V(14,1),V(14,2),'B14');
text(V(15,1),V(15,2),'B15');
text(V(16,1),V(16,2),'B16');
text(V(17,1),V(17,2),'B17');
hold on;
% plot term space
plot(U(:,1),U(:,2),'.');
text(U(1,1),U(1,2),'algorithms');
text(U(2,1),U(2,2),'applications');
text(U(3,1),U(3,2),'delay');
text(U(4,1),U(4,2),'differential');
text(U(5,1),U(5,2),'equations');
text(U(6,1),U(6,2),'implemntation');
text(U(7,1),U(7,2),'integral');
text(U(8,1),U(8,2),'introduction');
text(U(9,1),U(9,2),'methods');
text(U(10,1),U(10,2),'nonlinear');
text(U(11,1),U(11,2),'ordinary');
text(U(12,1),U(12,2),'oscillation');
text(U(13,1),U(13,2),'partial');
text(U(14,1),U(14,2),'problem');
text(U(15,1),U(15,2),'system');
text(U(16,1),U(16,2),'theory');
% If you are interested in "application(2nd term)" and "theory(17th
% term)", then the search direction is
d=[0 1 0 0 0 0 0 0 0 0 0 0 0 0 0 1]*U(:,1:2)*inv(S(1:2,1:2)); 

x=0:0.1:0.1
y=d(2).*x./d(1);
plot(x,y,'b-');
% If you have already read 4th, 8th, and 10th book, then what's the 
% search direction ?

%x=0:0.1:0.4
%y=d(2).*x./d(1);
%plot(x,y,'r-');
%hold off;
