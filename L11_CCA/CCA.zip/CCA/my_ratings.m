% regularization parameter
lambda = 5
% Check the file movie_idx.txt for id of each movie in our dataset
% For example, Toy Story (1995) has ID 1, so to rate it "4", you
% can set 
% my_ratings(1) = 4;
my_ratings(7) = 3;
my_ratings(11)= 5;
my_ratings(54) = 4;
my_ratings(64)= 5;
my_ratings(69) = 5;
my_ratings(72) = 5;
my_ratings(98) = 5;
my_ratings(183) = 4;
my_ratings(226) = 5;
my_ratings(333)= 4;