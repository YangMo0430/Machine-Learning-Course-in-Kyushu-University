function [] = amazonNNA(X,k);
% X=[1 3 4 0 0 0;0 3 5 0 0 5;0 0 4 5 0 5; 0 0 3 0 0 0;0 0 3 0 0 0]
% near-neighbor algorithm for collaborative filtering
% 
% Input
% X: rating matrix cotaining nonnegative integers.
% k: k-nearest-neighbor
%
% Output
% R: Recommendation matrix in the same size as X

[n p]=size(X);

if nargin < 2
  k = 1;
end

mu=mean(X,2)';

W=cor(X'); % compute user-user similarity based on correlation
for i=1:n
  W(i,i)=0;
end

[S I]=sort(W,'descend'); % sort similarity by descending order

disp(['users: ',num2str(1:n)]);
for j=1:k
  disp(['NN(', num2str(j),'): ',num2str(I(j,:))]);
end

R = zeros(n,p);
for i=1:n
  R(i,:) = mu(i); % compute recommendation
  temp = 0;
  for j=1:k
    R(i,:) += W(I(j,i),i)*(X(I(j,i),:)-mu(I(j,i))); % by weighted sum of k-nearest-neighbors
  end
end
R=R./sum(R,2);
[S I]=sort(R','descend');
disp(['recommendation: ',num2str(I(1,:))])