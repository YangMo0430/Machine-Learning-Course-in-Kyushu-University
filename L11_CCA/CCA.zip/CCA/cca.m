function [Wx Wy r U V] = cca(X,Y) 
 
C = cov([X Y]);  % covariance matrix
n = size(X,1);
sx = size(X,2); 
sy = size(Y,2); 
Cxx = C(1:sx, 1:sx) + 10^(-8)*eye(sx); 
Cxy = C(1:sx, sx+1:sx+sy); 
Cyx = Cxy'; 
Cyy = C(sx+1:sx+sy, sx+1:sx+sy) + 10^(-8)*eye(sy); 
 
% --- Calcualte Wx and r --- 
 
[Wx,r] = eig(inv(Cxx)*Cxy*inv(Cyy)*Cyx); % Basis in X 
r = real(sqrt(diag(r)));      % Canonical correlations 

% calculate Wy
Wy = inv(Cyy)*Cyx*Wx;     % Basis in Y 
Wy = Wy./repmat(sqrt(sum(abs(Wy).^2)),sy,1); % Normalize Wy 

U=(X-repmat(mean(X),n,1))*Wx;
V=(Y-repmat(mean(Y),n,1))*Wy;
