1. Explanation:

This demo shows a way to optimize parameters in Gaussian process wigh Gaussian kernel.
K = exp(tau)*exp(-tempK/exp(sigma)) + exp(delta)*eye(N),
where parameters {tau,sigma,delta} are fed into exponential.

First it shows GP fitting by the initial parameters. After hitting [Enter], it shows the reslts of optimization. The likelihood usually decreases, but not always.
So you may need to start from random initializations, and pick the best one in practice.

2. Usage:

./gp_opt_demo


3. Functions:

gp_opt_demo.m: demo script to show the effect of parameter optimization
init.m: load data				
plotgp.m: plot data
gpml_randn.m: random number generator
gpr.m: Gaussian process regression to compute likelihood, and gradients w.r.t. parameters		
kgauss.m: Gaussian kernel	
learngp.m: maximize likelihood based on gradient by calling fmincg
fmincg.m: conjugate gradient optimizer	


