function [best_para, J] = learngp(x,xs,y,init_sigma,init_delta,init_tau,opt)
% Objective: min J (or max L)
best_J = 1000000;
best_para = [];
params = [init_sigma; init_delta; init_tau];
%best_params = initial_parameters;
% Set options for fmincg
options = optimset('GradObj', 'on', 'MaxIter', 500);
costFunction = @(p) gpCostFunction(p,x,xs,y);
best_para = fmincg (costFunction, params, options);
[J] = gpCostFunction(best_para, x, xs, y)

plotgp(x,xs,y,best_para(1),best_para(2),best_para(3));

function [J grad] = gpCostFunction(params, x, xs, y)
sigma = params(1);
delta = params(2);
tau = params(3);
[alpha mu v logL dsigma ddelta dtau]=gpr(x,xs,y,sigma,delta,tau);
grad = [-dsigma; -ddelta; -dtau];
J = -logL;

