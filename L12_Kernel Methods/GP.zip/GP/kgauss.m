function [K tempK] = kgauss(X, sigma, delta, tau)
X = X';
%tau = 1;% eta = 0;
[D N] = size(X);
z = sum(X.^2,1);
tempK = repmat(z',1,N) + repmat(z,N,1) - 2 * X'*X;
%K = tau*exp(-tempK*exp(sigma)) + exp(delta)*eye(N);
K = exp(tau)*exp(-tempK/exp(sigma)) + exp(delta)*eye(N);
