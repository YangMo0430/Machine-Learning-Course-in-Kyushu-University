function [alpha mu v logL dsigma ddelta dtau K]=gpr(x,xs,y,sigma,delta,tau)
[ntr ptr] = size(x);
[nte pte] = size(xs);
[K tempK] = kgauss([x;xs],sigma,delta,tau);
%K += exp(delta)*eye(ntr+nte);
L = chol(K(1:ntr,1:ntr)); % K = L'*L
%L = chol(K(1:ntr,1:ntr)+eye(ntr));
alpha = L\(L'\y);
%alpha = K(1:ntr,1:ntr)\y;
ktr = K(1:ntr,1:ntr);
ktrte = K(1:ntr,ntr+1:end);
mu = ktrte'*alpha;
tempv = L'\ktrte;
v = diag(K(ntr+1:end,ntr+1:end))-diag(tempv'*tempv);

logL = -y'*alpha./2 - sum(log(diag(L))) - ntr * log(2*pi)/2;
temp = (alpha*alpha'-inv(ktr));
dsigma = trace( temp*( ktr - exp(delta)*eye(ntr) ) * exp(-sigma) * tempK(1:ntr,1:ntr))./2;
ddelta = trace( temp*exp(delta)*eye(ntr) )./2;
dtau = trace( temp*(ktr - exp(delta)*eye(ntr)) )./2;

