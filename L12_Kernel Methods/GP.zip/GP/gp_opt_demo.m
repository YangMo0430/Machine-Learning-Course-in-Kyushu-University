init; % load data
J=nan;
theta = randn(3,1); % initialize
theta(1) = exp(randn); %sigma
theta(2) = exp(randn); %delta
theta(3) = rand; %tau
disp(['sigma: ',num2str(theta(1)),' delta: ', num2str(theta(2)), ...
      ' tau: ', num2str(theta(3))])
hold off;plotgp(x,xs,y,theta(1),theta(2),theta(3))
disp('return enter');
kbhit();

[theta J]=learngp(x,xs,y,theta(1),theta(2),theta(3),'cg');
hold off;plotgp(x,xs,y,theta(1),theta(2),theta(3),J)

disp(['sigma: ',num2str(exp(theta(1))),' delta: ',num2str(exp(theta(2))), ' tau: ',num2str(exp(theta(3)))])