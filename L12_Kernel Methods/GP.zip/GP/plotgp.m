function [] = plotgp(x,xs,y,sigma,delta,tau,J);
hold off;
[alpha mu v logL a b c K] = gpr(x,xs,y,sigma,delta,tau);
%plot(x,y,'bo');
%plot(xs,mu,'rx');
f = [mu+2*sqrt(v); flip(mu-2*sqrt(v),1)];

fill([xs; flip(xs,1)], f, [7 7 7]/8);
hold on;
plot(xs, mu, 'b-'); plot(x, y, 'rx');
if(nargin>6)
  title(['logL: ',num2str(-J)]);
else
  title(['logL: ',num2str(logL)]);
end