n = 20;
  x = gpml_randn(0.3, 20, 1);                 % 20 training inputs
y = chol(K)'*gpml_randn(0.15, n, 1) + mu + exp(hyp.lik)*gpml_randn(0.2, n, 1);
  xs = linspace(-1.9, 1.9, 101)';                  % 61 test inputs 