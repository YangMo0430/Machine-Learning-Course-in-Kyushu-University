function [] = svm_rbf(C,sigma);
% read file
%data=load('ex8.txt');
%X=data(:,2:end);
%y=data(:,1);
load('ex6data2.mat');

%plotData(X, y);

% SVM Parameters
%C = 1; sigma = 0.1;
%C = 10; sigma = 0.1;
%C = 0.1; sigma = 0.1;

% train
model= svmTrain(X, y, C, @(x1, x2) gaussianKernel(x1, x2, sigma)); 
visualizeBoundary(X, y, model);

% accuracy
disp('Training Accuracy: ');
p = svmPredict(model,X);
sum(p==y)/length(y)*100
hold off;
refresh;
