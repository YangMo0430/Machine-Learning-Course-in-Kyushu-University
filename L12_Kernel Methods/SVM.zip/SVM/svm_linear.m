function [] = svm_linear(C);
% read file
data=load('twofeature.txt');
y=data(:,1);
X=data(:,2:end);
% plot
pos = (y==1);
neg = (y==0);
%X2=full(X);
plot(X(pos,1),X(pos,2),'ro');
hold on;
plot(X(neg,1),X(neg,2),'bo');

% train
model = svmTrain(X,y,C,@linearKernel,1e-3,20);

b=model.b;
w=model.w;
u = 0:1:5;
v = -(w(1).*u+b)./w(2);
plot(u,v,'k-');

%test
disp('Training Accuracy: ');
p = svmPredict(model,X);
sum(p==y)/length(y)*100
hold off;
refresh;
