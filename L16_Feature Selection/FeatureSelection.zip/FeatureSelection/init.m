load LongleyNorm.dat
