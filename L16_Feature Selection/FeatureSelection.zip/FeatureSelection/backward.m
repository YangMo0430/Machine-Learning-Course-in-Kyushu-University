function [BETA_out] = backward(X,y)
[n p] = size(X);
BETA_out = [];
BETA_in = [1:p];

beta = X\y;
minRSS = sum( (X*beta-y).^2);
prevAIC = n*log(minRSS/n)+2*(length(BETA_in));
printf("Start: AIC=%.3f\n",prevAIC);

while length(BETA_in) > 0

  RSSs = [];
  for j = 1:length(BETA_in)
    beta = zeros(length(BETA_in),1);
    _BETA_in = BETA_in;
    _BETA_in(j) = [];
    beta = X(:,_BETA_in)\y;
    RSSs = [RSSs sum( (X(:,_BETA_in)*beta - y).^2 )];
  end

  [minRSS newInd] = min(RSSs);
  AIC = n*log(minRSS/n)+2*(length(BETA_in));
  if AIC >= prevAIC
    break;
  else
    printf("RSS:%.3e %d deleted\tAIC:%.3f\n",minRSS,BETA_in(newInd),AIC);
    prevAIC = AIC;
  end

  BETA_out = [BETA_out BETA_in(newInd)];
  BETA_in(newInd) = [];

end
