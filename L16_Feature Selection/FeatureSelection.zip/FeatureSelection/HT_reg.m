function [] = HT_reg(X,y)
% Variable Selection by t_test, which is a mimic to R's command summary(lm(y~x))
%
% y: response variable (vector)
% X: explainatory variable (matrix)

[n p] = size(X);
%y = y - mean(y);
k = p;

beta = X\y;
printf("\nRegression with %d examples and %d predictors\n",n,p);

df = n - k ; % df = n - (p + 1) when without bias term
df1 = k - 1;
df2 = n - k;

RSS = sum((X*beta-y).^2); % Residual Sum of Squares
R2 = 1 - RSS/sum( (y-mean(y)).^2 );
sigma_hat2 = RSS/df;
AIC = n*log(2*pi) + n*log(RSS/n) + n + 2*(p+1);
%AIC = -2*log(RSS/n)+2*p;
H = X*inv(X'*X)*X';
SSReg = y'*(H-ones(n)./n)*y; % Regression Sum of Squares
SST = RSS + SSReg; % Total Sum of squares
SE = sqrt(diag(sigma_hat2*inv(X'*X)));
t = beta./SE;
pval_coeff = 2*min(1-tcdf(t,df),tcdf(t,df));

f = (SSReg/df1)/(RSS/df2);
pval_f = min(fcdf(f,df1,df2),1-fcdf(f,df1,df2));
disp(['RSS: ',num2str(RSS),' R-squared: ',num2str(R2), ' logL: ', num2str(log(RSS/n)),' AIC: ', num2str(AIC)]);
%disp(['SST: ',num2str(SST),' SSReg: ',num2str(SSReg)]);
disp(['residual standard error (sigma): ',num2str(sqrt(sigma_hat2))]);
printf("F-statistic: %.2e\n",f);

%disp(['degrees of freedom: ',num2str(df1), ' ', num2str(df2)]);
if pval_f > eps 
  printf("F-test p-value: %.2e",pval_f);
elseif pval_f <= eps
  printf("F-test p-value: <%.2e",eps);
else
  printf("F-test p-value undetermined");
end

if pval_f <= 0.001
  printf("(***)\n");
elseif pval_f < 0.01
  printf("(**)\n");
elseif pval_f < 0.05
  printf("(*)\n");
elseif pval_f < 0.1
  printf("(.)\n");
else
  printf("( )\n");
end

printf("\n");

printf("Estimate\t Std.Err\t t-statistic \t p-value\n");
RES = [beta SE t pval_coeff];

for i = 1:p
  if RES(i,4) < eps 
    printf("%.2e\t %.2e\t %.2e\t %.2e<(***)\n",RES(i,1),RES(i,2),RES(i,3),eps);
  elseif RES(i,4) <= 0.001
    printf("%.2e\t %.2e\t %.2e\t %.2e(***)\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  elseif RES(i,4) <= 0.01
    printf("%.2e\t %.2e\t %.2e\t %.2e(**)\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  elseif RES(i,4) <= 0.05
    printf("%.2e\t %.2e\t %.2e\t %.2e(*)\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  elseif RES(i,4) <= 0.1
    printf("%.2e\t %.2e\t %.2e\t %.2e(.)\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  else
    printf("%.2e\t %.2e\t %.2e\t %.2e( )\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  end
end

printf("\nSignif. codes: <%.3f (***) 0.001 (**) * 0.05 (.) 0.1 ( ) 1",eps);
printf("\n\n");

endfunction


