function [BETA_in] = hybrid(X,y)
[n p] = size(X);
BETA_in = [];
BETA_out = 1:p;

minRSS = sum(y.^2);
prevAIC = n*log(minRSS/n)+2*(length(BETA_in));
printf("Start: AIC=%.3f\n",prevAIC);

while length(BETA_out) > 0

  RSSs = [];
  for j = 1:length(BETA_out)
    beta = zeros(length(BETA_in)+1,1);
    beta = X(:,sort([BETA_in j]))\y;
    RSSs = [RSSs sum( (X(:,sort([BETA_in j]))*beta - y).^2 )];
  end

  for j = 1:length(BETA_in)
    beta = zeros(length(BETA_in),1);
    _BETA_in = BETA_in;
    _BETA_in(j) = [];
    beta = X(:,_BETA_in)\y;
    RSSs = [RSSs sum( (X(:,_BETA_in)*beta - y).^2 )];
  end

  [minRSS newInd] = min(RSSs);
  AIC = n*log(minRSS/n)+2*(length(BETA_in));
  if AIC >= prevAIC
    break;
  else
    prevAIC = AIC;
  end

  if newInd <= length(BETA_out)
    printf("RSS:%.3e %d added\tAIC:.%3f\n",minRSS,BETA_out(newInd),AIC);
  else
    printf("RSS:%.3e %d deleted\tAIC:.%3f\n",minRSS,BETA_in(newInd),AIC);
  end

  BETA_in = [BETA_in BETA_out(newInd) ];
  BETA_out(newInd) = [];

end
