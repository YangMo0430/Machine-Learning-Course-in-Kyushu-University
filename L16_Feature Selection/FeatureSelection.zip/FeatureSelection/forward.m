function [BETA_in] = forward(X,y)
[n p] = size(X);
BETA_in = [];
BETA_out = 1:p;

minRSS = sum(y.^2);
prevAIC = n*log(minRSS/n)+2*(length(BETA_in));
printf("Start: AIC=%.3f\n",prevAIC);

while length(BETA_out) > 0

  RSSs = [];
  for j = 1:length(BETA_out)
    beta = zeros(length(BETA_in)+1,1);
    beta = X(:,sort([BETA_in j]))\y;
    RSSs = [RSSs sum( (X(:,sort([BETA_in j]))*beta - y).^2 )];
  end

  [minRSS newInd] = min(RSSs);
  AIC = n*log(minRSS/n)+2*(length(BETA_in));
  if AIC >= prevAIC
    break;
  else
    printf("RSS:%.3e %d added\tAIC:.%3f\n",minRSS,BETA_out(newInd),AIC);
    prevAIC = AIC;
  end
  BETA_in = [BETA_in BETA_out(newInd) ];
  BETA_out(newInd) = [];

end

