function [beta, J, w] = logisticIRLSL1(X,y,lambda)
[n p] = size(X);
beta = zeros(p,1);
itr = 0;
J = 0;
while 1
  itr = itr + 1;
  prev_J = J;
%  J = -(y'*X*beta-sum(log(1+exp(X*beta))))+lambda*sum(abs(beta));
  J = -(y'*log(h(X*beta))+(ones(n,1)-y)'*log(ones(n,1)-h(X*beta))) + lambda*norm(beta,2)/2;
  if abs(prev_J-J) < 1/n break;  end

  W = diag(h(X*beta).*(ones(n,1)-h(X*beta)));
  z = X*beta + W\(y-h(X*beta));
  beta = (X'*W*X+lambda*pinv(diag(abs(beta))))\(X'*W*z);

end
disp(['converged in ',num2str(itr),' iterations']);
disp(['sparsity: ',num2str(sum(abs(beta)<0.001)/length(beta))]);
disp(['likelihood: ',num2str(-J)]);
endfunction

function [y] = h(x)
y = 1.0 ./ (1.0 + exp(-x));
endfunction
