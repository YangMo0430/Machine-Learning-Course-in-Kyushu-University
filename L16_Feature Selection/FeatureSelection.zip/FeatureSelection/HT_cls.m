function [] = HT_cls(X,y,opt)
% Variable Selection by t_test, which is a mimic to R's command summary(glm(y~x))
%
% y: response variable (vector)
% X: explainatory variable (matrix)
% opt: setting it to '1' forces classification and '2' forces regression

[n p] = size(X);
k = p;

[beta J w] = logistic(X,y,0);
printf("\nClassification with %d examples and %d predictors\n",n,p);

df = n - k ; % df = n - (p + 1) when without bias term
df1 = k - 1;
df2 = n - k;

logL = -J;
AIC = -2*logL+2*p;
SE = sqrt(diag(inv(X'*diag(w)*X)));
z = beta./SE;
%  pval_t = 2*min(1-tcdf(t,df),tcdf(t,df));
pval_coeff = 2*min(1-normcdf(beta,0,SE),normcdf(beta,0,SE));

disp(['logL: ', num2str(-J),' AIC: ', num2str(AIC)]);

printf("\n");

printf("Estimate\t Std.Err\t z-statistic \t p-value\n");
RES = [beta SE z pval_coeff];

for i = 1:p
  if RES(i,4) < eps 
    printf("%.2e\t %.2e\t %.2e\t %.2e<(***)\n",RES(i,1),RES(i,2),RES(i,3),eps);
  elseif RES(i,4) <= 0.001
    printf("%.2e\t %.2e\t %.2e\t %.2e(***)\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  elseif RES(i,4) <= 0.01
    printf("%.2e\t %.2e\t %.2e\t %.2e(**)\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  elseif RES(i,4) <= 0.05
    printf("%.2e\t %.2e\t %.2e\t %.2e(*)\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  elseif RES(i,4) <= 0.1
    printf("%.2e\t %.2e\t %.2e\t %.2e(.)\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  else
    printf("%.2e\t %.2e\t %.2e\t %.2e( )\n",RES(i,1),RES(i,2),RES(i,3),RES(i,4));
  end
end

printf("\nSignif. codes: <%.3f (***) 0.001 (**) * 0.05 (.) 0.1 ( ) 1",eps);
printf("\n\n");

endfunction

function [beta, J, w] = logistic(X,y,lambda)
[n p] = size(X);
beta = zeros(p,1);
itr = 0;
J = 0;
while 1
  itr = itr + 1;
  prev_J = J;
  J = sum(-y.*log(h(X*beta))-(1-y).*log(1-h(X*beta)));
  if abs(prev_J-J) < 1/n || itr > 100
    break;
  end

  w = h(X*beta).*(1-h(X*beta));
  z = X*beta + (y-h(X*beta))./w;
%  A = X'*diag(w)*X+lambda*diag([0 ones(1,p)]);
  A = X'*diag(w)*X+lambda*eye(p);
  b = X'*diag(w)*z;
  beta = A\b;
  old_beta = beta;

end
endfunction

function [y] = h(x)
y = 1.0 ./ (1.0 + exp(-x));
endfunction
